"""
Steps
-----
0. Download Cloud SDK https://cloud.google.com/sdk/docs/quickstart-windows
1. Install Python and PIP. 
2. Open CMD in the same folder where this GCS-Bucket.py is present & run pip install google-cloud-storage
3. Obtains user access credentials & authenicate using "gcloud auth application-default login"
"""

# Imports the Google Cloud client library
from google.cloud import storage

# Instantiates a client
storage_client = storage.Client()

# The name for the new bucket
bucket_name = "learn-gcp-pca-batch7"

# Creates the new bucket
bucket = storage_client.create_bucket(bucket_name)

print("Bucket {} created.".format(bucket.name))