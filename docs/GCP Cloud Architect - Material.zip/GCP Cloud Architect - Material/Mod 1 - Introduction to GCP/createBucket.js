/*
Steps
-----
0. Download Cloud SDK https://cloud.google.com/sdk/docs/quickstart-windows
1. Download Node JS https://nodejs.org/dist/v16.3.0/node-v16.3.0-x64.msi
2. Open CMD in the same folder where this createBucket.js is present & run npm install --save @google-cloud/storage
3. Obtains user access credentials & authenicate using "gcloud auth application-default login --no-launch-browser"
*/

'use strict';

const {Storage} = require('@google-cloud/storage');

// Your Google Cloud Platform project ID
const projectId = 'learn-gcp-pca-batch7';

// Creates a client
const storage = new Storage({
  projectId: projectId,
});

// The name for the new bucket
const bucketName = 'learn-gcp-pca-batch7-rest-nodejs-bucket';

// Creates the new bucket
async function createBucket() {
  await storage.createBucket(bucketName);
  console.log(`Bucket ${bucketName} created.`);
}

try {
  createBucket();
} catch (err) {
  console.error('ERROR:', err);
}