#! /bin/bash
Zone=$(curl -s http://metadata.google.internal/computeMetadata/v1/instance/zone -H "Metadata-Flavor: Google") 
InstanceName=$(curl -s http://metadata.google.internal/computeMetadata/v1/instance/name -H "Metadata-Flavor: Google")
Zone=$(echo $Zone | sed -n 's/\(.*\)zones\/\(.*\)/\2/p')
cat <<EOF > /var/www/html/index.html
<html><body><h1>Managed Instance Group in Action</h1>
<p>This request is served by $InstanceName which is present in $Zone zone.</p>
</body></html>
EOF