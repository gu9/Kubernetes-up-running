apt update
apt install -y apache2
