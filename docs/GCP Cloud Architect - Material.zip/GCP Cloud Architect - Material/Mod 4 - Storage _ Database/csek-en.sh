gsutil mb -c regional -l asia-southeast1 gs://$DEVSHELL_PROJECT_ID-csek
gsutil -o 'GSUtil:encryption_key='$1 cp demo-csek.txt gs://$DEVSHELL_PROJECT_ID-csek
