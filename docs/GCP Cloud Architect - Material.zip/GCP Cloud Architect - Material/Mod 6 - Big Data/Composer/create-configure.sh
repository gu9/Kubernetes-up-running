read -p "Set Project ID using below the command"
echo "export PROJECT=$DEVSHELL_PROJECT_ID"
export PROJECT=$DEVSHELL_PROJECT_ID

read -p "Set Composer instance name using below the command"
echo "export COMPOSER=$PROJECT-composer"
export COMPOSER=$PROJECT-composer

read -p "Test the $PROJECT and $COMPOSER values"
echo $PROJECT
echo $COMPOSER

read -p "Create a Composer in Mumbai using below the command"
read -p "gcloud composer environments create $COMPOSER --location asia-east2 --zone asia-east2-a --machine-type n1-standard-1 --python-version 3 --disk-size 20"
gcloud composer environments create $COMPOSER \
--location asia-east2 \
--zone asia-east2-a \
--machine-type n1-standard-1 \
--python-version 3 \
--disk-size 20

read -p "Create Regional GCS Storage using below the command"
echo "gsutil mb -c regional -l asia-east2 gs://$PROJECT-composer"
gsutil mb -c regional -l asia-east2 gs://$PROJECT-composer

read -p "Set GCP_PROJECT Airflow variables in Composer Environments using below the command"
echo "gcloud composer environments run $COMPOSER --location=asia-east2 variables -- --set gcp_project $PROJECT"
gcloud composer environments run $COMPOSER \
--location=asia-east2 variables -- \
--set gcp_project $PROJECT

read -p "Set GCE_ZONE Airflow variables in Composer Environments using below the command"
echo "gcloud composer environments run $COMPOSER --location=asia-east2 variables -- --set gce_zone asia-east1-a"
gcloud composer environments run $COMPOSER \
--location=asia-east2 variables -- \
--set gce_zone asia-east1-a

read -p "Set GCS_BUCKET Airflow variables in Composer Environments using below the command"
echo "gcloud composer environments run $COMPOSER --location=asia-east2 variables -- --set gcs_bucket gs://$PROJECT-composer"
gcloud composer environments run $COMPOSER \
--location=asia-east2 variables -- \
--set gcs_bucket gs://$PROJECT-composer

read -p "Copy hadoop_tutorial.py to DAG"

