from google.cloud import pubsub_v1
import random

publisher = pubsub_v1.PublisherClient()
topic_name = 'projects/{project_id}/topics/{topic}'.format(
    project_id='YOUR-PROJECT-ID',
    topic='demo-topic', 
)
for i in range(0,20):
    playerID = random.randint(100,200)
    score = random.randint(10,100)
    userName = "userName"+str(playerID)
    data = '{"playerID":'+str(playerID)+',"score":'+str(score)+',"userName":"'+userName+'"}'    
    print(data+"\n")
    publisher.publish(topic_name, bytes(data, 'utf-8'))
